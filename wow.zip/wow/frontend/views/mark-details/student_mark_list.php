<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\MarkDetailsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Mark Details';
$this->params['breadcrumbs'][] = $this->title;
?>
<div id='w0' class="grid-view">
<div class="summary">
   <table class="table table-striped table-bordered">
	<thead>
		<tr>
			<th>Student Name</th>
			<th>English</th>
			<th>Maths</th>
			<th>Science</th>
			<th>Total</th>
			<th>AVG</th>
			<th>#</th>
		</tr>
	</thead>
	<tbody class="ui-sortable">
		<?php
			$cls_avg_eng		=	0;
			$cls_avg_maths		=	0;
			$cls_avg_science	=	0;
			$cls_avg_total		=	0;
			$cls_avg			=	0;
			foreach($result as $value)
			{
				//echo'<pre>';print_r($result);exit;
				$arr_mark	=	array();
				foreach($value['markdetails'] as $val)
				{
					if($val['subject_id']==1)
					{
						$arr_mark['english']	=	$val['mark'];
					}else if($val['subject_id']==2)
					{
						$arr_mark['maths']	=	$val['mark'];
					}else if($val['subject_id']==3)
					{
						$arr_mark['science']	=	$val['mark'];
					}
				}
			?>
			
				<tr>
					<td><?php echo $value['name']; ?></td>
					<td><?php echo $english	=	isset($arr_mark['english'])?$arr_mark['english']:0; ?></td>
					<td><?php echo $maths	=	isset($arr_mark['maths'])?$arr_mark['maths']:0; ?></td>
					<td><?php echo $science	=	isset($arr_mark['science'])?$arr_mark['science']:0; ?></td>
					<td><?php echo $total	=	$english+$maths+$science;	; ?></td>
					<td><?php echo number_format($total/3,2); ?></td>
					<td><?= Html::a('Update', ['update', 'id' => $value['id']], ['class' => 'btn btn-primary']) ?></td>
				</tr>
			
			<?php
			$cls_avg_eng=$cls_avg_eng+$english;
			$cls_avg_maths=$cls_avg_maths+$maths;
			$cls_avg_science=$cls_avg_science+$science;
			$cls_avg_total=$cls_avg_total+$total;
			$cls_avg=$cls_avg+number_format($total/3,2);
			}
			?>
			</tbody>
			<thead>
		<thead>
			<th>Class AVG</th>
			<th><?php echo $cls_avg_eng/count($result); ?></th>
			<th><?php echo $cls_avg_maths/count($result); ?></th>
			<th><?php echo $cls_avg_science/count($result); ?></th>
			<th><?php echo $cls_avg_total; ?></th>
			<th><?php echo number_format($cls_avg/count($result),2); ?></th>
			
		<thead>
		
</table>
</div>
