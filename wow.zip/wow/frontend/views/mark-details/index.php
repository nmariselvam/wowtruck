<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\MarkDetailsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Mark Details';
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="mark-details-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Mark Details', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
			[
				'attribute' => 'student_id',
				'label' => 'Student Name',
				'value' => 'student.name',
			],
			[
				'attribute' => 'subject_id',
				'label' => 'Subject Name',
				'value' => 'subject.name',
			],
			[
				'attribute' => 'subject_id',
				'label' => 'Subject Name',
				'value'=>function($model)
				{
					return "tt";
				},
			],
			[
				'attribute' => 'subject_id',
				'label' => 'Subject Name',
				'value' => 'subject.name',
			],
			[
				'attribute' => 'subject_id',
				'label' => 'Subject Name',
				//'value' => '',
			],
            'mark',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
