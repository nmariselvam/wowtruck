<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "mark_details".
 *
 * @property integer $id
 * @property integer $student_id
 * @property integer $subject_id
 * @property integer $mark
 */
class MarkDetails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'mark_details';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['student_id', 'subject_id', 'mark'], 'required'],
            [['student_id', 'subject_id', 'mark'], 'integer']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'student_id' => 'Student ID',
            'subject_id' => 'Subject ID',
            'mark' => 'Mark',
        ];
    }
	public function get_student_list($id=null)
    {
		if(isset($id))
		{
			return $query = Student::find()->where(['student.id'=>$id])->joinWith('markdetails')->asArray()->one();
		}else{
			return $query = Student::find()->joinWith('markdetails')->asArray()->all();
		}
		
	}
	
	 public function getSubject()
    {
		 return $this->hasOne(Subject::className(), ['id' => 'subject_id']);
    }
	 public function getStudent()
    {
		 return $this->hasOne(Student::className(), ['id' => 'student_id']);
    }
}
