<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "student".
 *
 * @property integer $id
 * @property integer $name
 * @property string $father_name
 * @property string $address
 */
class Student extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'father_name', 'address'], 'required'],
            [['father_name'], 'string', 'max' => 100],
            [['address'], 'string', 'max' => 150]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'father_name' => 'Father Name',
            'address' => 'Address',
        ];
    }
	
	 public function getMarkdetails()
    {
		 return $this->hasMany(Markdetails::className(), ['student_id' => 'id']);
    }
}
